package com.ltts.ShopInfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopInfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
