package com.ltts.ShopInfo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopInfoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShopInfoApplication.class, args);
	}

}
