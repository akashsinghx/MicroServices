package com.ltts.Basket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasketApplicationTests {

	@Test
	void contextLoads() {
	}

}
